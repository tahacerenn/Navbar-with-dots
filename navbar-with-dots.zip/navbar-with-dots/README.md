# Nav Bar with Dots

This repo is the corresponding code for this [tutorial](https://www.blog.karenying.com/posts/nav-bar-with-dots) in which we use React Router and clever CSS to create a nav bar with dots to show hover and active state. See the final product deployed [here](https://nav-bar-with-dots.netlify.app/).

## Installation

1. Clone this repo
2. `npm install`
3. `npm start`
