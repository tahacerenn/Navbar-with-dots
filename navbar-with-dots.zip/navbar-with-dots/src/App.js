import { BrowserRouter as Router, Route } from "react-router-dom";
import web from "./img/Web.png";
import Foto from "./img/Foto.jpg";
import foto2 from "./img/foto2.jpg";

import "./App.css";
import Header from "./Header";

const Home = () => (
  <div>
    <img style={{ width: 1920, height: 960 }} src={web} alt={"web"} />
  </div>
);

const Users = () => (
  <div>
    <div class="row">
      <div class="col-sm-6">
        <div class="card">
          <img
            src={Foto}
            alt={"Foto"}
            style={{
              resizeMode: "cover",
              height: 200,
              width: 200,
            }}
          />
          <h1>Taha Ceren</h1>
          <p class="title">Junior Software Engineer,</p>
          <p>Gebze Technical University</p>
          <span>
            {"  "}
            <a href="#">
              <i class="fa fa-dribbble"></i>
            </a>
            {"  "}
            <a href="#">
              <i class="fa fa-twitter"></i>
            </a>
            {"  "}
            <a href="https://www.linkedin.com/in/tahaceren">
              <i class="fa fa-linkedin"></i>
            </a>
            {"  "}
            <a href="#">
              <i class="fa fa-facebook"></i>
            </a>
          </span>
          <br />
          <button
            onClick={() => {
              document.getElementById("mail1").innerHTML =
                "mt_ceren@hotmail.com";
            }}
          >
            Contact1
          </button>
          <p id="mail1"></p>
          <div id="mail1"></div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="card">
          <img
            src={foto2}
            alt={"foto2"}
            style={{
              resizeMode: "cover",
              height: 200,
              width: 200,
            }}
          />
          <h1>Omer Eren</h1>
          <p class="title">Senior Software Engineer,</p>
          <p>Harvard University</p>
          <span>
            {"  "}
            <a href="#">
              <i class="fa fa-dribbble"></i>
            </a>
            {"  "}
            <a href="#">
              <i class="fa fa-twitter"></i>
            </a>
            {"  "}
            <a href="#">
              <i class="fa fa-linkedin"></i>
            </a>
            {"  "}
            <a href="#">
              <i class="fa fa-facebook"></i>
            </a>
          </span>
          <br />
          <button
            onClick={() => {
              document.getElementById("mail2").innerHTML =
                "battlelamb2@hotmail.com";
            }}
          >
            Contact2
          </button>
          <p id="mail2"></p>
          <div id="mail2"></div>
        </div>
      </div>
    </div>
  </div>
);

const Contact = () => (
  <div>
    <h1>Contact</h1>
    <h2>Adress: Basari Sk. Erdi Plus No:3 D:1 Bakirkoy </h2>
    <h2> Tel:0123456789 </h2>
  </div>
);

function App() {
  return (
    <div className="App">
      <Router>
        <Route path="/:page" component={Header} />
        <Route exact path="/" component={Header} />

        <Route exact path="/" component={Home} />
        <Route exact path="/home" component={Home} />
        <Route exact path="/Users" component={Users} />
        <Route exact path="/contact" component={Contact} />
      </Router>
    </div>
  );
}

export default App;
